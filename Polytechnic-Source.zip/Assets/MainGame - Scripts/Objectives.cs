using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class Objectives : MonoBehaviour
{
    public TextMeshProUGUI timeObj;
    public TextMeshProUGUI killObj;
    // Start is called before the first frame update
    void Start()
    {
        //Make one objective for timer, and one for killing all enemies. 
        //Also make a highscore system to save those objectives
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
