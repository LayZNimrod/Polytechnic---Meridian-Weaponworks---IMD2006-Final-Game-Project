    ____  ____  ____  ______________________  ___   ____________
   / __ \/ __ \/ /\ \/ /_  __/ ____/ ____/ / / / | / /  _/ ____/
  / /_/ / / / / /  \  / / / / __/ / /   / /_/ /  |/ // // /     
 / ____/ /_/ / /___/ / / / / /___/ /___/ __  / /|  // // /___   
/_/    \____/_____/_/ /_/ /_____/\____/_/ /_/_/ |_/___/\____/   
                                                                
BY MERIDIAN WEAPONWORKS (ROWAN, CHLOE, ZACH)

CREDITS:

- SFX: Copyright Free sounds from https://freesound.org and https://www.bluezone-corporation.com/

- UI Sprites: Free use sprites by Positron on Itch.io! https://positron.itch.io/steampunk-fantasy-ui-pack

- All other spritework (Player, enemies, BG, Tilemap, etc): Created by our team!

- Logo: Created by Rowan!

- Music: Created by Zach!

